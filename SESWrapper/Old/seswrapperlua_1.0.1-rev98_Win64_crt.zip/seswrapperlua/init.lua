package.cpath = package.cpath .. ";dll\\?.dll;SES_1.4.0/dll/?.dll"

seswrapper = require("SESWrapperLua")

function help(a)
  print(seswrapper.help(a))
end

function print_error(code)
  print(seswrapper.WRP_GetPropertyString("lib_error", code))
end

seswrapper.loadWrapper("dll/SESWrapper")
--seswrapper.WRP_SetPropertyString("lib_working_dir", "SES_1.4.0")
--seswrapper.WRP_SetPropertyString("instrument_library", "dll/SESInstrument")
seswrapper.WRP_Initialize(0)
seswrapper.WRP_LoadInstrument("data/Instrument.dat")
