Installing SESWrapperLua
------------------------

* Copy the SESWrapperLua.dll file to the /dll directory of your SES installation.
* Copy the other files (init.lua, lua.exe, lua5.2.dll and luac.exe) to the directory where Ses.exe is located.
* You may need to modify the init.lua file to make it open another Instrument Configuration file (change the call to WRP_LoadInstrument).

Running SESWrapperLua
---------------------

* Start Lua.exe
* Type the following line to open SESWrapperLua and SESWrapper (see the contents of the init.lua script):

  dofile("init.lua")

* To see which SESWrapper functions are available you can call the follwing function:

  help()

  or

  help(<function name>)

  or

  help(<structure name>)

  For example, calling 

* The init.lua script creates a table called seswrapper to access the SESWrapper functions. You can change this name at any time, e.g. by modifying
  init.lua before calling it.

  For example, changing the kinetic energy is done by typing the following:

  seswrapper.WRP_SetKineticEnergy(10)

  and to see the current kinetic energy you can use the print() Lua function:

  print(seswrapper.WRP_GetKineticEnergy())

* Before closing the Lua.exe command window you need to call

  seswrapper.WRP_Finalize()

  If you forget to do this, the application will probably crash. This is because SES needs a clean shut-down of the sub-libraries (notable the Detector and
  Supply libraries).

* If something goes wrong when using SESWrapperLua you can use the print_error(code) function to let the program print a text showing the corresponding text
  related to the error code "code". If this fails it is possible that SESWrapper could not be opened. If you don't get any useful information from this
  function, you may still be able to find out the cause of the error by reading the seswrapper.log file, which is often created and updated when a call
  to an SESInstrument function fails.
